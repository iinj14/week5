package com.skooldio.android.fundamentals.workshop.pomodoro.config

object NotificationConfig {
    const val CHANNEL_NAME = "Default"
    const val CHANNEL_ID = "default"
}
